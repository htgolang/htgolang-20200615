package plugins

import (
	_ "github.com/imsilence/gocmdb/server/cloud/plugins/tenant"
	_ "github.com/imsilence/gocmdb/server/cloud/plugins/aliyun"
)
