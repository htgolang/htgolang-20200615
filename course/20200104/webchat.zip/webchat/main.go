package main

import (
	"fmt"
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/orm"
	_ "webchat/routers"
	_ "github.com/go-sql-driver/mysql"
)

func main() {
	driverSource := fmt.Sprintf("%s:%s@tcp(%s:%s)/%s?charset=utf8mb4&loc=Local",
		beego.AppConfig.String("dbuser"),
		beego.AppConfig.String("dbpassword"),
		beego.AppConfig.String("dbhost"),
		beego.AppConfig.String("dbport"),
		beego.AppConfig.String("dbname"),
	)
	orm.RegisterDataBase("default", "mysql", driverSource)

	orm.RunSyncdb("default", false, true)
	// 启动beego 服务
	beego.Run()
}