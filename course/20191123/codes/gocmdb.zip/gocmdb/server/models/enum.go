package models

const (
	StatusUnlock = 0
	StatusLock   = 1
)
